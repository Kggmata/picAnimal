const constantDict = {
  drawerOpenVelocityXThreshold: 1600,
  topTabHeaderColor: '#dce35b',
  commonSeparator: '-',
  commonSeparatorOfForumLike: ';',
  commonSeparatorOfSpecialist: '::',
  numberOfTagButtons: 20,
  viewHistorySize: 10,
};
export default constantDict;
