const baiduToken = {
  refresh_token:
    '25.35c184ba206cde5f5e8aa70ac45597cf.315360000.1978916770.282335-27531950',
  expires_in: 2592000,
  session_key:
    '9mzdWW9k9cUjUPs5vzMqPz9bjvMqAfHvBAQT6UmMCf0cHwcCOFd3Ol+6WrBoVSMphxlCDUmypfkRdw47srJmsvQWp70sqg==',
  access_token:
    '24.b5116a5bed83eaf43e4d82684a11aeea.2592000.1666148770.282335-27531950',
  scope:
    'public vis-classify_dishes vis-classify_car brain_all_scope vis-classify_animal vis-classify_plant brain_object_detect brain_realtime_logo brain_dish_detect brain_car_detect brain_animal_classify brain_plant_classify brain_ingredient brain_advanced_general_classify brain_custom_dish brain_poi_recognize brain_vehicle_detect brain_redwine brain_currency brain_vehicle_damage brain_multi_ object_detect brain_vehicle_attr wise_adapt lebo_resource_base lightservice_public hetu_basic lightcms_map_poi kaidian_kaidian ApsMisTest_Test\u6743\u9650 vis-classify_flower lpq_\u5f00\u653e cop_helloScope ApsMis_fangdi_permission smartapp_snsapi_base smartapp_mapp_dev_manage iop_autocar oauth_tp_app smartapp_smart_game_openapi oauth_sessionkey smartapp_swanid_verify smartapp_opensource_openapi smartapp_opensource_recapi fake_face_detect_\u5f00\u653eScope vis-ocr_\u865a\u62df\u4eba\u7269\u52a9\u7406 idl-video_\u865a\u62df\u4eba\u7269\u52a9\u7406 smartapp_component smartapp_search_plugin avatar_video_test b2b_tp_openapi b2b_tp_openapi_online smartapp_gov_aladin_to_xcx',
  session_secret: '0e1441069e2589c6fd4147b5f0faf232',
};
const APIKey =
  '24.b5116a5bed83eaf43e4d82684a11aeea.2592000.1666148770.282335-27531950';
